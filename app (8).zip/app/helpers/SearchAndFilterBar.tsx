"use client";

import { useEffect, useRef, useState } from "react";
import { ChevronDown, Search } from "lucide-react";

export type FilterOption = {
  label: string;
  value: string;
};

type SearchAndFilterBarProps = {
  searchValue: string;
  searchPlaceholder: string;
  filterValue: string;
  filterPlaceholder: string;
  filterOptions: FilterOption[];
  onSearch: (query: string) => void;
  onFilterChange: (value: string) => void;
};

export default function SearchAndFilterBar({
  searchValue,
  searchPlaceholder,
  filterValue,
  filterPlaceholder,
  filterOptions,
  onSearch,
  onFilterChange,
}: SearchAndFilterBarProps) {
  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const filterRef = useRef<HTMLDivElement>(null);

  const selectedOption = filterOptions.find(
    (option) => option.value === filterValue,
  );

  useEffect(() => {
    if (!isFilterOpen) {
      return;
    }

    function handlePointerDown(event: PointerEvent) {
      if (!filterRef.current?.contains(event.target as Node)) {
        setIsFilterOpen(false);
      }
    }

    document.addEventListener("pointerdown", handlePointerDown);

    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
    };
  }, [isFilterOpen]);

  return (
    <form
      className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between"
      onSubmit={(event) => {
        event.preventDefault();

        const formData = new FormData(event.currentTarget);
        const query = String(formData.get("query") ?? "");

        onSearch(query);
      }}
    >
      <div className="flex w-full items-center gap-2 border-b border-gray-200 pb-2 text-gray-400 sm:max-w-md">
        <Search className="h-4 w-4" />

        <input
          key={searchValue}
          name="query"
          type="text"
          defaultValue={searchValue}
          placeholder={searchPlaceholder}
          className="w-full text-xs outline-none placeholder:text-gray-400"
        />
      </div>

      <div className="flex items-center gap-3">
        <button
          type="submit"
          className="rounded bg-gray-100 px-4 py-2 text-xs font-semibold text-gray-700"
        >
          Search
        </button>

        <div ref={filterRef} className="relative w-56">
          <button
            type="button"
            onClick={() => setIsFilterOpen((value) => !value)}
            className={`flex w-full items-center justify-between rounded border bg-white px-4 py-2 text-left text-xs text-gray-500 outline-none ${
              isFilterOpen ? "border-blue-500" : "border-gray-200"
            }`}
          >
            <span className="truncate">
              {selectedOption?.label ?? filterPlaceholder}
            </span>

            <ChevronDown className="h-4 w-4" />
          </button>

          {isFilterOpen && (
            <div className="absolute right-0 top-10 z-20 max-h-64 w-full overflow-auto rounded border border-gray-200 bg-white py-2 shadow-sm">
              {filterOptions.map((option) => (
                <button
                  key={option.value}
                  type="button"
                  onClick={() => {
                    onFilterChange(option.value);
                    setIsFilterOpen(false);
                  }}
                  className="block w-full px-4 py-2 text-left text-sm text-gray-800 hover:bg-gray-50"
                >
                  {option.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>
    </form>
  );
}
