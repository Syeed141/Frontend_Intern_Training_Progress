type IconChipProps = {
  label: string;
  image?: string;
  isActive?: boolean;
  onClick: () => void;
};

export default function IconChip({
  label,
  image,
  isActive = false,
  onClick,
}: IconChipProps) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`inline-flex cursor-pointer items-center gap-2 rounded border px-3 py-2 text-xs font-semibold shadow-sm transition hover:-translate-y-0.5 hover:shadow-md active:translate-y-px active:scale-[0.98] ${
        isActive
          ? "border-blue-300 bg-blue-50 text-blue-600"
          : "border-gray-200 bg-white text-gray-700 hover:border-blue-200 hover:bg-blue-50"
      }`}
    >
      {image && (
        <img
          src={image}
          alt=""
          className="h-4 w-4 rounded-sm object-contain"
        />
      )}

      <span>{label}</span>
    </button>
  );
}
