import { ChevronRight, PencilLine } from "lucide-react";
import Pagination from "@/app/components/common/Pagination";
import { formatShortDate } from "@/app/helpers/dateHelpers";
import type { ResourceItem } from "../../../../types/ControlRoomTypes";

type ResourceTableProps = {
  resources: ResourceItem[];
  totalItems: number;
  currentPage: number;
  pageSize: number;
  isLoading: boolean;
  isError: boolean;
  onPageChange: (page: number) => void;
};

export default function ResourceTable({
  resources,
  totalItems,
  currentPage,
  pageSize,
  isLoading,
  isError,
  onPageChange,
}: ResourceTableProps) {
  const totalPages = Math.ceil(totalItems / pageSize);

  return (
    <div className="mt-6">
      <div className="overflow-hidden rounded-lg border border-gray-100">
        <table className="w-full border-collapse text-left text-xs">
          <thead className="bg-slate-50 text-[11px] font-bold uppercase text-slate-500">
            <tr>
              <th className="w-10 px-4 py-3">
                <input type="checkbox" className="h-4 w-4 rounded border-gray-200" />
              </th>
              <th className="px-4 py-3">Resource Name</th>
              <th className="px-4 py-3">Tool</th>
              <th className="px-4 py-3">Resource Type</th>
              <th className="px-4 py-3">Date</th>
              <th className="px-4 py-3 text-right">Action</th>
            </tr>
          </thead>

          <tbody>
            {isLoading && (
              <tr>
                <td
                  colSpan={6}
                  className="px-4 py-8 text-center text-sm text-gray-500"
                >
                  Loading resources...
                </td>
              </tr>
            )}

            {isError && !isLoading && (
              <tr>
                <td
                  colSpan={6}
                  className="px-4 py-8 text-center text-sm text-red-500"
                >
                  Failed to load resources.
                </td>
              </tr>
            )}

            {!isLoading && !isError && resources.length === 0 && (
              <tr>
                <td
                  colSpan={6}
                  className="px-4 py-8 text-center text-sm text-gray-500"
                >
                  No resources found.
                </td>
              </tr>
            )}

            {!isLoading &&
              !isError &&
              resources.map((resource) => (
                <tr key={resource._id} className="border-t border-gray-100">
                  <td className="px-4 py-4">
                    <input
                      type="checkbox"
                      className="h-4 w-4 rounded border-gray-200"
                    />
                  </td>

                  <td className="px-4 py-4 font-medium text-gray-700">
                    {resource.name}
                  </td>

                  <td className="px-4 py-4 text-gray-600">
                    <div className="flex items-center gap-2">
                      {resource.tool.logo && (
                        <img
                          src={resource.tool.logo}
                          alt=""
                          className="h-4 w-4 rounded-sm object-contain"
                        />
                      )}

                      <span>{resource.tool.name}</span>
                    </div>
                  </td>

                  <td className="px-4 py-4 text-gray-600">
                    {resource.type.name}
                  </td>

                  <td className="px-4 py-4 text-gray-600">
                    {formatShortDate(resource.created_at)}
                  </td>

                  <td className="px-4 py-4">
                    <div className="flex justify-end gap-4 text-gray-500">
                      <button type="button" aria-label="Edit resource">
                        <PencilLine className="h-4 w-4" />
                      </button>

                      <button type="button" aria-label="Open resource">
                        <ChevronRight className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>

      <div className="mt-5 flex items-center justify-between text-xs text-gray-400">
        <p>
          Showing{" "}
          <span className="font-semibold text-gray-600">
            {resources.length}
          </span>{" "}
          out of{" "}
          <span className="font-semibold text-gray-600">{totalItems}</span>
        </p>

        <Pagination
          currentPage={currentPage}
          totalPages={totalPages}
          onPageChange={onPageChange}
        />
      </div>
    </div>
  );
}
