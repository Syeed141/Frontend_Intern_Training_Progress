import IconChip from "@/app/components/common/IconChip";
import type { ResourceTool } from "../../../../types/ControlRoomTypes";

type ToolsSectionProps = {
  tools: ResourceTool[];
  selectedToolId: string;
  isLoading: boolean;
  onToolChange: (toolId: string) => void;
};

export default function ToolsSection({
  tools,
  selectedToolId,
  isLoading,
  onToolChange,
}: ToolsSectionProps) {
  return (
    <div className="rounded-lg border border-gray-100 p-4">
      <p className="mb-3 text-xs font-semibold text-gray-500">Tools</p>

      {isLoading ? (
        <p className="text-sm text-gray-400">Loading tools...</p>
      ) : tools.length === 0 ? (
        <p className="text-sm text-gray-400">No tools found.</p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {/* <IconChip
            label="All tools"
            isActive={!selectedToolId}
            onClick={() => onToolChange("")}
          /> */}

          {tools.map((tool) => (
            <IconChip
              key={tool.toolId}
              label={tool.toolName}
              image={tool.logo}
              isActive={tool.toolId === selectedToolId}
              onClick={() => onToolChange(tool.toolId)}
            />
          ))}
        </div>
      )}
    </div>
  );
}