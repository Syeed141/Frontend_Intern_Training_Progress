"use client";

import { useEffect } from "react";
import {
  useFieldArray,
  useFormContext,
  useWatch,
} from "react-hook-form";
import { useQuery } from "@tanstack/react-query";
import { CircleMinus } from "lucide-react";

import type { CreateProductFormInput } from "@/app/schemas/createProductSchema";
import { getRateSheetDetails } from "@/app/services/productApi";

export function RateSheetMembersSection() {
  const {
    control,
    register,
    formState: { errors },
  } = useFormContext<CreateProductFormInput>();

  // 1. Watch selected rate sheet
  const selectedRateSheetId = useWatch({
    control,
    name: "rateSheetId",
  });

  // 2. Fetch rate sheet details when rateSheetId changes
  const { data: rateSheetDetails } = useQuery({
    queryKey: ["rate-sheet-details", selectedRateSheetId],
    queryFn: () => getRateSheetDetails(selectedRateSheetId),
    enabled: Boolean(selectedRateSheetId),
  });

  // 3. Manage dynamic array forms
  const { fields, replace, remove } = useFieldArray({
    control,
    name: "rateSheetMembers",
  });

  // 4. When API response comes, create one form per role
  useEffect(() => {
    if (!rateSheetDetails?.teamStructures) {
      replace([]);
      return;
    }

    const formsFromApi = rateSheetDetails.teamStructures.map((item) => {
      return {
        teamStructureId: item._id,
        employeeRoleId: item.employeeRoleId,
        roleName: item.role?.name ?? "",
        internalRate: item.internalRate,
        billRate: item.billRate,

        teamMemberId: "",
        workType: "",
        startDate: "",
        endDate: "",
      };
    });

    replace(formsFromApi);
  }, [rateSheetDetails, replace]);

  // Do not show anything until user selects a rate sheet
  if (!selectedRateSheetId || !rateSheetDetails) {
    return null;
  }

  return (
    <div className="mt-6 rounded-md border bg-white">
      {/* Header */}
      <div className="flex items-center justify-between border-b px-6 py-4">
        <div className="flex items-center gap-3">
          <h3 className="font-semibold">
            {rateSheetDetails.name} <span className="text-red-500">*</span>
          </h3>

          <span className="text-sm text-gray-500">
            With {fields.length} roles
          </span>
        </div>

        <button type="button" className="text-sm font-medium text-blue-600">
          Save members
        </button>
      </div>

      {/* Dynamic role forms */}
      {fields.map((field, index) => (
        <div
          key={field.id}
          className="relative border-b px-6 py-6 last:border-b-0"
        >
          {/* Remove button */}
          <button
            type="button"
            onClick={() => remove(index)}
            className="absolute right-6 top-6 text-red-500"
          >
            <CircleMinus className="h-5 w-5" />
          </button>

          {/* Rates */}
          <p className="mb-4 text-sm text-gray-500">
            Internal Rate: ${field.internalRate} /month{" "}
            <span className="ml-4">
              Billing Rate: ${field.billRate} /month
            </span>
          </p>

          {/* Hidden fields*/}
          <input
            type="hidden"
            {...register(`rateSheetMembers.${index}.teamStructureId`)}
          />

          <input
            type="hidden"
            {...register(`rateSheetMembers.${index}.employeeRoleId`)}
          />

          <input
            type="hidden"
            {...register(`rateSheetMembers.${index}.roleName`)}
          />

          <input
            type="hidden"
            {...register(`rateSheetMembers.${index}.internalRate`, {
              valueAsNumber: true,
            })}
          />

          <input
            type="hidden"
            {...register(`rateSheetMembers.${index}.billRate`, {
              valueAsNumber: true,
            })}
          />

          {/* Form fields */}
          <div className="grid grid-cols-2 gap-4">
            {/* Team Member */}
            <div>
              <label className="mb-1 block text-sm font-medium">
                Team Member <span className="text-red-500">*</span>
              </label>

              <select
                {...register(`rateSheetMembers.${index}.teamMemberId`, {
                  required: "Team member is required",
                })}
                className="w-full rounded-md border px-3 py-2 text-sm"
              >
                <option value="">Select</option>
                <option value="member-1">Member 1</option>
                <option value="member-2">Member 2</option>
              </select>

              {errors.rateSheetMembers?.[index]?.teamMemberId && (
                <p className="mt-1 text-sm text-red-500">
                  {errors.rateSheetMembers[index]?.teamMemberId?.message}
                </p>
              )}
            </div>

            {/* Work Type */}
            <div>
              <label className="mb-1 block text-sm font-medium">
                Work Type <span className="text-red-500">*</span>
              </label>

              <select
                {...register(`rateSheetMembers.${index}.workType`, {
                  required: "Work type is required",
                })}
                className="w-full rounded-md border px-3 py-2 text-sm"
              >
                <option value="">Select</option>
                <option value="full-time">Full Time</option>
                <option value="part-time">Part Time</option>
                
              </select>

              {errors.rateSheetMembers?.[index]?.workType && (
                <p className="mt-1 text-sm text-red-500">
                  {errors.rateSheetMembers[index]?.workType?.message}
                </p>
              )}
            </div>

            {/* Start Date */}
            <div>
              <label className="mb-1 block text-sm font-medium">
                Start Date <span className="text-red-500">*</span>
              </label>

              <input
                type="date"
                {...register(`rateSheetMembers.${index}.startDate`, {
                  required: "Start date is required",
                })}
                className="w-full rounded-md border px-3 py-2 text-sm"
              />

              {errors.rateSheetMembers?.[index]?.startDate && (
                <p className="mt-1 text-sm text-red-500">
                  {errors.rateSheetMembers[index]?.startDate?.message}
                </p>
              )}
            </div>

            {/* End Date */}
            <div>
              <label className="mb-1 block text-sm font-medium">
                End Date
              </label>

              <input
                type="date"
                {...register(`rateSheetMembers.${index}.endDate`)}
                className="w-full rounded-md border px-3 py-2 text-sm"
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
