import { NextResponse } from "next/server";

type DashboardResponse = {
  message: string;
};

export async function GET(request: Request) {
  const authorization = request.headers.get("authorization");

  if (!authorization) {
    const errorResponse: DashboardResponse = {
      message: "Authorization token is missing.",
    };

    return NextResponse.json(errorResponse, { status: 401 });
  }

  return NextResponse.json({
    message: "Dashboard request authenticated.",
   
  });
}
