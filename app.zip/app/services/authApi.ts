import axios from "axios";
import {
  LoginErrorResponse,
  LoginRequestBody,
  LoginSuccessResponse,
} from "../types/auth";

export type LoginApiError = {
  response: LoginErrorResponse;
};

const accessTokenKeys = new Set([
  "accessToken",
  
]);

const refreshTokenKeys = new Set([
  "refreshToken",
  
]);

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function findStringValue(
  value: unknown,
  keys: Set<string>
): string | undefined {
  if (!isRecord(value)) {
    return undefined;
  }

  for (const [key, fieldValue] of Object.entries(value)) {
    if (keys.has(key) && typeof fieldValue === "string" && fieldValue) {
      return fieldValue;
    }
  }

  for (const fieldValue of Object.values(value)) {
    const nestedValue = findStringValue(fieldValue, keys);

    if (nestedValue) {
      return nestedValue;
    }
  }

  return undefined;
}

function loginError(message: string): LoginApiError {
  return {
    response: {
      message,
    },
  };
}

export async function loginUser(
  body: LoginRequestBody
): Promise<LoginSuccessResponse> {
  const clientId = process.env.NEXT_PUBLIC_CLIENT_ID;
  const clientSecret = process.env.NEXT_PUBLIC_CLIENT_SECRET;
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL;

  

  try {
    const response = await axios.post(`${baseUrl}/auth/sign-in`, body, {
      headers: {
        "Content-Type": "application/json",
        Authorization: `Basic ${btoa(`${clientId}:${clientSecret}`)}`,
      },
    });

    const result: unknown = response.data;
    const accessToken = findStringValue(result, accessTokenKeys);
    const refreshToken = findStringValue(result, refreshTokenKeys);
    const email = findStringValue(result, new Set(["email"])) ?? body.email;

    if (!accessToken) {
      throw loginError(
        "Login succeeded but the server did not return an access token."
      );
    }

    if (!refreshToken) {
      throw loginError(
        "Login succeeded but the server did not return a refresh token."
      );
    }

    return {
      accessToken,
      refreshToken,
      email,
    };
  } catch (error) {
    if (axios.isAxiosError(error)) {
      throw loginError(
        "There is an issue with the credentials you have entered. Please try again."
      );
    }

    throw error;
  }
}
